#include "lab_m1/Tema2/Tema2.h"

#include <vector>
#include <string>
#include <iostream>

using namespace std;
using namespace m1;


/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */

class Tank : public gfxc::SimpleScene {

public:
	Tank::Tank()
	{
	}


	Tank::~Tank()
	{
	}

public:
	float speedAll = 2;
	float speedRotTurret = 2;
	float speedRotCannon = 2;
	glm::vec3 body_pos = glm::vec3(0, 0.5, 0);
	glm::vec3 cannon_pos = glm::vec3(0, 0.53, 0);
	glm::vec3 turret_pos = glm::vec3(0, 0.61, 0);
	glm::vec3 scale = glm::vec3(0.5, 0.5, 0.5);
};
